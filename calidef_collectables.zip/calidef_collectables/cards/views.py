# cards/views.py
from django.shortcuts import render

def card_view(request):
    return render(request, 'cards/card.html')
